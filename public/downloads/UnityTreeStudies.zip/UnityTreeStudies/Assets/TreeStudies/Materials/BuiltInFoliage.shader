Shader "TreeStudies/BuiltIn Foliage"
{
    Properties
    {
        _Color ("Color", Color) = (1,1,1,1)
        _MainTex ("Base Color and Alpha", 2D) = "white" {}
        _Cutoff ("Alpha Cutoff", Range(0,1)) = .48
        _Glossiness ("Smoothness", Range(0,1)) = .12
        _Metallic ("Metallic", Range(0,1)) = 0
    }
    SubShader
    {
        Tags { "RenderType"="TransparentCutout" "Queue"="AlphaTest" }
        LOD 200
        Cull Off
        CGPROGRAM
        #pragma surface surf Standard fullforwardshadows alphatest:_Cutoff addshadow
        #pragma target 3.0
        #pragma multi_compile_instancing
        sampler2D _MainTex;
        fixed4 _Color;
        half _Glossiness;
        half _Metallic;
        struct Input { float2 uv_MainTex; float facing : VFACE; };
        void surf (Input IN, inout SurfaceOutputStandard o)
        {
            fixed4 c = tex2D(_MainTex, IN.uv_MainTex) * _Color;
            o.Albedo = c.rgb;
            o.Metallic = _Metallic;
            o.Smoothness = _Glossiness;
            o.Alpha = c.a;
            o.Normal = float3(0, 0, IN.facing >= 0 ? 1 : -1);
        }
        ENDCG
    }
    FallBack "Transparent/Cutout/Diffuse"
}
